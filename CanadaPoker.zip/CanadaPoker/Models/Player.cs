﻿namespace CanadaHoldemPoker.Models
{
	public class Player
	{
		public string name = "";

		public Player(string name)
		{
			this.name = name;
		}
	}
}
